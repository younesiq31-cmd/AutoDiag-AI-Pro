import 'dart:convert';
import 'dart:typed_data';
import 'package:bluetooth_serial_android/bluetooth_serial_android.dart';

class ObdService {
  final BluetoothSerialAndroid _serial = BluetoothSerialAndroid();
  bool isConnected = false;

  Future<bool> connect() async {
    // Real adapter discovery/selection is intentionally not guessed.
    // The Android layer must supply a paired OBDLink MX+ device.
    try {
      final devices = await _serial.getBondedDevices();
      if (devices.isEmpty) return false;
      // The plugin API can vary by version/device. Keep the driver conservative:
      // no fake success and no fabricated ECU data.
      return false;
    } catch (_) {
      return false;
    }
  }

  Future<Map<String, String>> readLiveData() async {
    if (!isConnected) return {};
    return {};
  }

  Future<List<String>> readDtcs() async {
    if (!isConnected) return [];
    return [];
  }

  Uint8List _bytes(String command) => Uint8List.fromList(utf8.encode('$command\r'));

  void dispose() {
    _serial.disconnect();
  }
}
