import 'package:flutter/material.dart';
import 'services/obd/obd_service.dart';

void main() {
  runApp(const AutoDiagAIProApp());
}

class AutoDiagAIProApp extends StatelessWidget {
  const AutoDiagAIProApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'AutoDiag AI Pro',
      theme: ThemeData.dark(useMaterial3: true),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final obd = ObdService();
  String status = 'Demo / غير متصل';
  List<String> dtcs = const [];
  Map<String, String> live = const {};

  Future<void> connect() async {
    final ok = await obd.connect();
    setState(() => status = ok ? 'Real OBDLink / متصل' : 'تعذر الاتصال');
  }

  Future<void> scan() async {
    if (!obd.isConnected) {
      setState(() => status = 'لا يوجد اتصال حقيقي بـ ECU');
      return;
    }
    final data = await obd.readLiveData();
    final codes = await obd.readDtcs();
    setState(() {
      live = data;
      dtcs = codes;
      status = 'فحص حقيقي مكتمل';
    });
  }

  @override
  void dispose() {
    obd.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('AutoDiag AI Pro')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text('محرك التشخيص Evidence‑First',
                        style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    Text(status),
                    const SizedBox(height: 16),
                    FilledButton.icon(
                      onPressed: connect,
                      icon: const Icon(Icons.bluetooth),
                      label: const Text('اتصال OBDLink MX+'),
                    ),
                    const SizedBox(height: 10),
                    OutlinedButton.icon(
                      onPressed: scan,
                      icon: const Icon(Icons.car_repair),
                      label: const Text('بدء فحص حقيقي'),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text('Live Data', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    if (live.isEmpty)
                      const Text('لا توجد بيانات — لن نعرض أرقامًا وهمية.')
                    else
                      ...live.entries.map((e) => ListTile(
                            dense: true,
                            title: Text(e.key),
                            trailing: Text(e.value),
                          )),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text('DTC', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    if (dtcs.isEmpty)
                      const Text('لم يتم استلام أكواد أعطال حقيقية.')
                    else
                      ...dtcs.map((c) => ListTile(
                            leading: const Icon(Icons.warning_amber),
                            title: Text(c),
                          )),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
