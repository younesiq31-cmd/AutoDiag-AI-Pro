import 'package:flutter_test/flutter_test.dart';
import 'package:autodag_ai_pro/main.dart';

void main() {
  testWidgets('AutoDiag AI Pro starts without fake ECU data', (tester) async {
    await tester.pumpWidget(const AutoDiagAIProApp());
    expect(find.text('AutoDiag AI Pro'), findsOneWidget);
    expect(find.text('لا توجد بيانات — لن نعرض أرقامًا وهمية.'), findsOneWidget);
  });
}
